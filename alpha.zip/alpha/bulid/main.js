var build = document.getElementById("build");

var height,
		half;

window.addEventListener("resize", adjustHeightVars);
window.addEventListener("scroll", fadeBox);

function fadeBox () {	
	// var x = build.offsetTop - half;
	// var y = window.pageYOffset;
	// if (y >= x) {
	// 	$(".image").addClass("fadein");
	// }
    var image=document.getElementsByClassName("image")[0]
    console.log(image)
    image.animate({'opacity':1},1500);
}

function adjustHeightVars() {
	height = window.innerHeight;
	half = height * 0.35;
}

adjustHeightVars();